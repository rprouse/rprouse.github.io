#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: Copier.cs
// Date:     06/06/2008 11:18 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

#endregion

using System;

namespace Alteridem.ModelViewHelpers
{
    /// <summary>
    /// Copier
    /// </summary>
    public sealed class Copier<T1> where T1 : class
    {
        #region Private Members

        private readonly T1 _subject;

        #endregion

        #region Public Interface

        /// <summary>
        /// Begin the copying process.
        /// </summary>
        /// <param name="interface1">The object you are copying from or to</param>
        /// <returns>An instance of the Copier class so that you can 
        /// continue with the copy to/from in a fluent interface.</returns>
        public static Copier<T1> Copy( T1 interface1 )
        {
            return new Copier<T1>( interface1 );
        }

        #endregion

        #region Construction

        /// <summary>
        /// Private constructor so that it can only be created as a part of a fluent interface.
        /// </summary>
        /// <param name="subject"></param>
        private Copier( T1 subject )
        {
            _subject = subject;
        }

        #endregion

        #region Copier Methods

        /// <summary>
        /// Copies properties from the subject to the passed in object.
        /// </summary>
        /// <typeparam name="T2">The type of object you are copying into.</typeparam>
        /// <param name="to">The object to copy into.</param>
        /// <returns>The modified object that you passed in.</returns>
        public T2 To<T2>( T2 to ) where T2 : class
        {
            CopyHelper.Copy( typeof( T1 ), _subject, typeof( T2 ), to );
            return to;
        }

        /// <summary>
        /// Copies properties from the passed in object into the subject.
        /// </summary>
        /// <typeparam name="T2">The type of object you are copying from.</typeparam>
        /// <param name="from">The object to copy from.</param>
        /// <returns>The modified subject that you originally passed in the Copy method.</returns>
        public T1 From<T2>( T2 from ) where T2 : class
        {
            CopyHelper.Copy( typeof( T2 ), from, typeof( T1 ), _subject );
            return _subject;
        }

        #endregion
    }
}