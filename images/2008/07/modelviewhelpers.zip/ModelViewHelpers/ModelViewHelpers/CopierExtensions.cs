#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: CopierExtensions.cs.cs
// Date:     06/06/2008 2:39 PM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

#endregion

namespace Alteridem.ModelViewHelpers
{
    /// <summary>
    /// CopierExtensions.cs
    /// </summary>
    public static class CopierExtensions
    {
        public static void CopyTo<T>( this object from, T to ) where T : class
        {
            CopyHelper.Copy( from.GetType(), from, typeof( T ), to );
        }

        public static void CopyFrom<T>( this object to, T from ) where T : class
        {
            CopyHelper.Copy( typeof( T ), from, to.GetType(), to );
        }
    }
}