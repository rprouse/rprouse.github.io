#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: CopyTestsBase.cs
// Date:     06/06/2008 10:49 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    public class CopyTestsBase
    {
        #region Helper Methods

        internal static void CheckThatCustomerEqualsView( ICustomer customer, ICustomerView view )
        {
            Assert.That( view.Address, Is.EqualTo( customer.Address ) );
            Assert.That( view.Country, Is.EqualTo( customer.Country ) );
            Assert.That( view.FirstName, Is.EqualTo( customer.FirstName ) );
            Assert.That( view.LastName, Is.EqualTo( customer.LastName ) );
            Assert.That( view.PostalCode, Is.EqualTo( customer.PostalCode ) );
            Assert.That( view.Province, Is.EqualTo( customer.Province ) );
        }

        internal static void ChangeView( ICustomerView view )
        {
            view.LastName = "New LastName";
            view.FirstName = "New FirstName";
            view.Address = "New Address";
            view.Close();
        }

        internal static void CheckThatCustomerDoesNotEqualView( ICustomer customer, ICustomerView view )
        {
            Assert.That( view.Address, Is.Not.EqualTo( customer.Address ) );
            Assert.That( view.Country, Is.EqualTo( customer.Country ) );
            Assert.That( view.FirstName, Is.Not.EqualTo( customer.FirstName ) );
            Assert.That( view.LastName, Is.Not.EqualTo( customer.LastName ) );
            Assert.That( view.PostalCode, Is.EqualTo( customer.PostalCode ) );
            Assert.That( view.Province, Is.EqualTo( customer.Province ) );
        }

        internal static void CheckChangesToCustomer( ICustomer customer )
        {
            Assert.That( customer.LastName, Is.EqualTo( "New LastName" ) );
            Assert.That( customer.FirstName, Is.EqualTo( "New FirstName" ) );
            Assert.That( customer.Address, Is.EqualTo( "New Address" ) );
        }

        #endregion
    }
}