#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: CopyHelperTests.cs
// Date:     06/06/2008 10:49 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

using System;
using System.Diagnostics;
using NUnit.Framework;
using NUnit.Framework.SyntaxHelpers;

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// CopierTests
    /// </summary>
    [TestFixture]
    public class CopyHelperTests : CopyTestsBase
    {
        #region Tests

        [Test]
        public void TimeCopyHelper()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            for ( int i = 0; i < 10000; i++ )
            {
                CopyInterfacesAsInterfaces();
            }

            stopwatch.Stop();
            Console.WriteLine( "CopyHelper copy took {0} ms", stopwatch.ElapsedMilliseconds );
        }

        [Test]
        public void CopyInterfacesAsInterfaces()
        {
            ICustomer customer = new Customer();
            ICustomerView view = new CustomerView();

            // Copy the data from the customer to the view
            CopyHelper.Copy( typeof(ICustomer), customer, typeof(ICustomerView), view );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Pretend the user has modified the view and hit save, close or whatever
            // Pretend the user has changed some data
            ChangeView( view );

            // Make sure the data we expect has changed
            CheckThatCustomerDoesNotEqualView( customer, view );

            // We now copy the data from the view back into the customer
            CopyHelper.Copy( typeof( ICustomerView ), view, typeof( ICustomer ), customer );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Make sure it is the data that we expect
            CheckChangesToCustomer( customer );
        }

        [Test]
        public void CopyClassesAsInterfaces()
        {
            Customer customer = new Customer();
            CustomerView view = new CustomerView();

            // Copy the data from the customer to the view
            CopyHelper.Copy( typeof( ICustomer ), customer, typeof( ICustomerView ), view );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Pretend the user has modified the view and hit save, close or whatever
            // Pretend the user has changed some data
            ChangeView( view );

            // Make sure the data we expect has changed
            CheckThatCustomerDoesNotEqualView( customer, view );

            // We now copy the data from the view back into the customer
            CopyHelper.Copy( typeof( ICustomerView ), view, typeof( ICustomer ), customer );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Make sure it is the data that we expect
            CheckChangesToCustomer( customer );
        }

        [Test]
        public void CopyClassesAsClasses()
        {
            Customer customer = new Customer();
            CustomerView view = new CustomerView();

            // Copy the data from the customer to the view
            CopyHelper.Copy( typeof( Customer ), customer, typeof( CustomerView ), view );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Pretend the user has modified the view and hit save, close or whatever
            // Pretend the user has changed some data
            ChangeView( view );

            // Make sure the data we expect has changed
            CheckThatCustomerDoesNotEqualView( customer, view );

            // We now copy the data from the view back into the customer
            CopyHelper.Copy( typeof( CustomerView ), view, typeof( Customer ), customer );

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Make sure it is the data that we expect
            CheckChangesToCustomer( customer );
        }

        [Test]
        public void TestCopyingToSelf()
        {
            ICustomer customer = new Customer();

            CopyHelper.Copy( typeof( ICustomer ), customer, typeof( ICustomer ), customer );
        }

        [Test]
        [ExpectedException( typeof( ArgumentNullException ) )]
        public void TestNullSubjectTo()
        {
            ICustomer customer = new Customer();
            ICustomerView view = null;

            CopyHelper.Copy( typeof( ICustomer ), customer, typeof( ICustomerView ), view );
        }

        [Test]
        [ExpectedException( typeof( ArgumentNullException ) )]
        public void TestNullObjectTo()
        {
            ICustomer customer = null;
            ICustomerView view = new CustomerView();

            CopyHelper.Copy( typeof( ICustomer ), customer, typeof( ICustomerView ), view );
        }

        [Test]
        [ExpectedException( typeof( ArgumentNullException ) )]
        public void TestNullSubjectFrom()
        {
            ICustomer customer = new Customer();
            ICustomerView view = null;

            CopyHelper.Copy( typeof( ICustomerView ), view, typeof( ICustomer ), customer );
        }

        [Test]
        [ExpectedException( typeof( ArgumentNullException ) )]
        public void TestNullObjectFrom()
        {
            ICustomer customer = null;
            ICustomerView view = new CustomerView();

            CopyHelper.Copy( typeof( ICustomerView ), view, typeof( ICustomer ), customer );
        }

        [Test]
        public void TestNullProperties()
        {
            ICustomer customer = new Customer();
            ICustomerView view = new CustomerView();

            customer.Address = null;

            CopyHelper.Copy( typeof( ICustomer ), customer, typeof( ICustomerView ), view );
            Assert.That( view.Address, Is.Null );
        }

        #endregion
    }
}