#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: CustomerView.cs
// Date:     06/06/2008 10:30 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// CustomerView
    /// </summary>
    public class CustomerView : ICustomerView
    {
        #region ICustomerView Members

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Address { get; set; }

        public string PostalCode { get; set; }

        public string Province { get; set; }

        public string Country { get; set; }

        public string UniqueIdentifier { get; set; }

        public string GetOnly
        {
            get { return string.Empty; }
        }

        public string SetOnly
        {
            set { /* Do nothing */ }
        }

        public void Close()
        {
            // Do nothing, I just wanted a method to make sure it is okay.
        }

        #endregion
    }
}