#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: CopyHelperTests.cs
// Date:     06/06/2008 10:49 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

using System;
using System.Diagnostics;
using NUnit.Framework;

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// CopierTests
    /// </summary>
    [TestFixture]
    public class RegularCopyTests : CopyTestsBase
    {
        #region Tests

        [Test]
        public void TimeRegularCopy()
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            for ( int i = 0; i < 10000; i++ )
            {
                TestRegularCopy();
            }

            stopwatch.Stop();
            Console.WriteLine( "Regular copy took {0} ms", stopwatch.ElapsedMilliseconds );
        }

        [Test]
        public void TestRegularCopy()
        {
            ICustomer customer = new Customer();
            ICustomerView view = new CustomerView();

            // Copy the data from the customer to the view
            view.Address = customer.Address;
            view.Country = customer.Country;
            view.FirstName = customer.FirstName;
            view.LastName = customer.LastName;
            view.PostalCode = customer.PostalCode;
            view.Province = customer.Province;

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Pretend the user has modified the view and hit save, close or whatever
            // Pretend the user has changed some data
            ChangeView( view );

            // Make sure the data we expect has changed
            CheckThatCustomerDoesNotEqualView( customer, view );

            // We now copy the data from the view back into the customer
            customer.Address = view.Address;
            customer.Country = view.Country;
            customer.FirstName = view.FirstName;
            customer.LastName = view.LastName;
            customer.PostalCode = view.PostalCode;
            customer.Province = view.Province;

            // Do some tests to ensure the data went across okay.
            CheckThatCustomerEqualsView( customer, view );

            // Make sure it is the data that we expect
            CheckChangesToCustomer( customer );
        }

        #endregion
    }
}