#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: Customer.cs
// Date:     06/06/2008 10:27 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

using System;

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// Customer
    /// </summary>
    public class Customer : ICustomer
    {
        #region Construction

        public Customer()
        {
            // Create a dummy customer
            Id = 1234;
            LastName = "LastName";
            FirstName = "FirstName";
            Address = "Address";
            PostalCode = "PostalCode";
            Province = "Province";
            Country = "Country";
            CreatedOn = DateTime.Now;

            UniqueIdentifier = Guid.NewGuid();
        }

        #endregion

        #region ICustomer Members

        public int Id { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string Address { get; set; }

        public string PostalCode { get; set; }

        public string Province { get; set; }

        public string Country { get; set; }

        public DateTime CreatedOn { get; set; }

        public Guid UniqueIdentifier { get; set; }

        #endregion
    }
}