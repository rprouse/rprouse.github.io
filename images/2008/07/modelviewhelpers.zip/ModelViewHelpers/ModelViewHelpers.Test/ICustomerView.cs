#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ICustomerView.cs
// Date:     06/06/2008 10:26 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// ICustomerView
    /// </summary>
    public interface ICustomerView
    {
        string FirstName { get; set; }
        string LastName { get; set; }
        string Address { get; set; }
        string PostalCode { get; set; }
        string Province { get; set; }
        string Country { get; set; }

        // Include some properties with same name, but different type
        string UniqueIdentifier { get; set; }

        // Include some get/set only properties that should be ignored
        string GetOnly { get; }
        string SetOnly { set; }

        // Include a method to make sure everything works
        void Close();
    }
}