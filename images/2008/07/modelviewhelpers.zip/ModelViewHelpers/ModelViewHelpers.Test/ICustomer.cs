#region Copyright � Alteridem Consulting 2008

//
// All rights are reserved. Reproduction or transmission in whole or in part, in
// any form or by any means, electronic, mechanical or otherwise, is prohibited
// without the prior written consent of the copyright owner.
//
// Filename: ICustomer.cs
// Date:     06/06/2008 10:23 AM
// Author:   Rob Prouse
//

#endregion

#region Using Directives

using System;

#endregion

namespace Alteridem.ModelViewHelpers.Test
{
    /// <summary>
    /// ICustomer
    /// </summary>
    public interface ICustomer
    {
        int Id { get; set; }
        string FirstName { get; set; }
        string LastName { get; set; }
        string Address { get; set; }
        string PostalCode { get; set; }
        string Province { get; set; }
        string Country { get; set; }
        DateTime CreatedOn { get; set; }

        // Include some properties with same name, but different type
        Guid UniqueIdentifier { get; set; }
    }
}